package text.bwei.com.sss;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by dell on 2018/2/3.
 */

public class Myadapter extends RecyclerView.Adapter {


    private ArrayList<String> s1;
    private Context context;

    public Myadapter(ArrayList<String> s1, Context context) {
        this.s1 = s1;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new Mycleview(inflate);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Mycleview mycleview = (Mycleview) holder;


        s1 = new ArrayList<>();
        s1.add("ssss");
        s1.add("ssss");
        s1.add("ssss");
        s1.add("ssss");
        s1.add("ssss");
        mycleview.viewById.setText(s1.get(position));


    }

    @Override
    public int getItemCount() {
        return s1.size();
    }

    class Mycleview extends RecyclerView.ViewHolder {


        private final TextView viewById;

        public Mycleview(View itemView) {
            super(itemView);
            viewById = itemView.findViewById(R.id.ssss);
        }
    }

}
