package text.bwei.com.sss;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import java.util.ArrayList;

/**
 * Created by dell on 2018/2/3.
 */

public class StandardActivity extends Activity implements View.OnClickListener {


    private View activityStandardView;
    private SimpleDraweeView sdvImageCircleActivityStandardView;
    /**
     * 品保标准
     */
    private TextView pingbiaoActivityStandardView;
    private RecyclerView recyclerAddActivityStandardView;
    private ArrayList<String> s1;
    private  boolean err;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_standard);


        initView();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        s1 = new ArrayList<String>();
        s1.add("ssss");
        s1.add("ssss");
        s1.add("ssss");
        s1.add("ssss");
        s1.add("ssss");
        recyclerAddActivityStandardView.setLayoutManager(linearLayoutManager);
        recyclerAddActivityStandardView.setAdapter(new Myadapter(s1, this));
        pingbiaoActivityStandardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (err) {

                    recyclerAddActivityStandardView.setVisibility(View.VISIBLE);
                    err=false;

                } else {

                    recyclerAddActivityStandardView.setVisibility(View.GONE);
                err=true;
                }

            }
        });




    }


    private void initView() {
        activityStandardView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.activity_standard, null);
        sdvImageCircleActivityStandardView = (SimpleDraweeView) findViewById(R.id.sdv_image_circle);
        sdvImageCircleActivityStandardView.setOnClickListener(this);
        pingbiaoActivityStandardView = (TextView) findViewById(R.id.pingbiao);
        pingbiaoActivityStandardView.setOnClickListener(this);
        recyclerAddActivityStandardView = (RecyclerView) findViewById(R.id.recycler_add);
        recyclerAddActivityStandardView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            default:
                break;
            case R.id.sdv_image_circle:
                break;
            case R.id.pingbiao:



                break;
            case R.id.recycler_add:
                break;
        }
    }
}
