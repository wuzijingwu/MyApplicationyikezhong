package text.bwei.com.sss;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;

import java.util.ArrayList;

/**
 * Created by dell on 2018/2/3.
 */

public class MymainAdapter extends RecyclerView.Adapter {


    private ArrayList list;
    private Context context;

    public MymainAdapter(ArrayList list, Context context) {
        this.list = list;
        this.context = context;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(parent.getContext()).inflate(R.layout.activitymain_item, parent, false);
        return new MyViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        MyViewHolder myViewHolder = (MyViewHolder) holder;
       myViewHolder.name.setText(list.get(position).toString());
        myViewHolder.simpleDraweeView.setImageURI("http://p2.so.qhimgs1.com/bdr/200_200_/t0133d63eaab554b8de.jpg");
        myViewHolder.buttonone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, StandardActivity.class);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {


        private final SimpleDraweeView simpleDraweeView;
        private final TextView name;
        private final Button buttonone;
        private final Button buttontwo;

        public MyViewHolder(View itemView) {
            super(itemView);
            simpleDraweeView = itemView.findViewById(R.id.sdv_image_circle);
            name = itemView.findViewById(R.id.name);
            buttonone = itemView.findViewById(R.id.buttonone);
            buttontwo = itemView.findViewById(R.id.buttontwo);


        }
    }

}
